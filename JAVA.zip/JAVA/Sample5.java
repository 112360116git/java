public class Sample5
{
	public static void main(String[] args)
	{
		System.out.println("八進位數101的字元是\101");
		System.out.println("十六進位數0061的字元是\u0061");
	}
}
