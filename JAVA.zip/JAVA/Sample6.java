public class Sample6
{
	public static void main(String[] args)
	{
		System.out.println("十進位的10是"+10);
		System.out.println("八進位的10是"+010);
		System.out.println("十六進位的10是"+0x10);
		System.out.println("十六進位的F是"+0xF);
	}
}
