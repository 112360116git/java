public class Sample4
{
	public static void main(String[] args)
	{
		System.out.println("顯示出反斜線:\\");
		System.out.println("顯示出單引號\'");
	}
}

