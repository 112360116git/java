public class Sample2
{
	public static void main(String[] args)
	{
		System.out.println("歡迎使用Java");
		System.out.println("開始使用Java吧!");
	}
}
