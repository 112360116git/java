public class Sample8
{
	public static void main(String[] args)
	{
		int num = 3;
		System.out.println("變數num的值是" + num);
		num = 5;
		System.out.println("更新變數num的值");
		System.out.println("變數num更新後的值是" + num);
	}
}
